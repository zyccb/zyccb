# 证据强度控制清单

Use this file before accepting or rewriting any strong scientific claim. If the provided text does not show the required evidence, weaken the claim or flag it.

## Basic Rule

Never upgrade evidence. A rewrite may make wording clearer, but it must not turn:

- correlation into causation;
- expression difference into functional validation;
- phenotype association into mechanism;
- reporter activity into direct binding;
- trend into significant difference;
- one material or time point into a general species-level conclusion.

## Claim Strength Ladder

| Evidence shown in text | Safer wording | Avoid unless extra evidence exists |
| --- | --- | --- |
| Descriptive measurement | "观察到", "检测到", "表现为" | "导致", "决定", "证明" |
| Statistical difference with threshold | "显著升高/降低", "差异显著" | Broader biological mechanism claims |
| Trend without statistical support | "呈升高趋势", "有所增加" | "显著", "明显证明" |
| Correlation analysis | "与...相关", "呈正/负相关" | "调控", "促进", "抑制", "导致" |
| RNA-seq/qRT-PCR expression | "表达水平升高/降低", "转录水平变化" | "蛋白增加", "功能增强", "直接调控" |
| Protein assay such as Western blot or targeted proteomics | "蛋白积累增加/减少" | "转录水平升高", unless transcript data also exists |
| Mutant/OE/RNAi/VIGS phenotype | "影响", "参与", "可能在...中发挥作用" | "直接调控", "阐明机制" |
| Promoter reporter assay only | "影响启动子活性", "可能调控转录活性" | "直接结合启动子" |
| EMSA, Y1H, ChIP-qPCR, DAP-seq, CUT&Tag, or equivalent binding evidence | "结合...启动子/位点" | "在所有组织中直接调控", unless shown |
| Binding evidence plus reporter/phenotype | "可能直接调控", "支持其直接参与..." | Over-generalized pathway-level claims |
| Y2H, BiFC, Co-IP, pull-down, split-luc, FRET, or equivalent | "互作", "存在蛋白互作证据" | "形成复合体并调控...", unless downstream evidence exists |

## Significance Terms

Use "显著" only when the sentence or surrounding context provides statistical support, such as p-value, q-value, confidence interval, test method, figure/table annotation, or explicit statement of significance.

If not shown, use:

- "升高/降低"
- "呈升高/降低趋势"
- "差异较大"
- "在本实验条件下表现出差异"

Do not silently add thresholds such as `P < 0.05`.

## Mechanism Claims

Use "机制", "分子机制", "调控网络", or "通路" only when the text provides enough evidence for mechanism-level interpretation. A candidate gene list, enrichment result, or correlation network is usually not enough.

Safer alternatives:

- "为解析...机制提供候选基因"
- "提示...可能参与..."
- "支持...与...相关"
- "仍需遗传转化、互作验证或靶基因验证进一步确认"

## Regulation Claims

Distinguish:

- **直接调控**: requires binding evidence to the target locus or equivalent direct evidence, ideally with reporter or expression support.
- **调控启动子活性**: reporter assay supports promoter activity changes, but not necessarily direct binding.
- **影响表达**: expression changes in mutants, treatments, or transgenic lines.
- **相关表达**: correlation or co-expression only.

If the original text says "调控" but evidence is unclear, prefer "可能影响" or mark `[调控证据不足]`.

## Interaction Claims

Use "互作" only when interaction assays are provided. If only co-expression, same pathway annotation, or co-localization is shown, use "可能存在关联" or "可能参与同一过程".

Single-method interaction evidence should be phrased carefully:

- "Y2H 结果提示二者可能互作"
- "BiFC 结果支持二者在细胞内存在互作"
- "Co-IP 进一步验证了二者在该体系中的互作"

## Functional Validation

Do not treat omics screening as functional validation. Functional validation usually requires perturbation or genetic evidence such as mutant, overexpression, RNAi, VIGS, complementation, CRISPR/Cas editing, transient expression with phenotype readout, or rescue assays.

Use "候选", "可能", "有待验证" for genes identified only by expression, association, GWAS/QTL, WGCNA, or enrichment analysis.
