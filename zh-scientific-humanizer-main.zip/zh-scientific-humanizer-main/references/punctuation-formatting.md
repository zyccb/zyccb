# 中文科研标点、数字、单位和格式

Use this file when cleaning formatting in Chinese scientific manuscript text. Preserve journal-specific style when known.

## Punctuation

- Use Chinese punctuation for Chinese prose: `，` `。` `；` `：` `（ ）`.
- Preserve half-width punctuation in formulas, accession IDs, gene constructs, file names, URLs, and citations when already present.
- Do not apply English-only rules such as Title Case conversion, curly quotes conversion, or em dash preference to Chinese scientific text.
- Avoid changing single quotes around cultivar names unless the user asks for a style pass.

## Numbers and Units

Preserve values, units, decimals, significant digits, and ranges exactly unless correcting a clear typographic inconsistency requested by the user.

Protect examples:

- `25 °C`, `25℃`, `10 mg/L`, `100 μmol/L`, `1.5 mL`, `3 d`, `0 h`, `24 h`
- `P < 0.05`, `P < 0.01`, `p < 0.05`, `q < 0.05`
- `n = 3`, `mean ± SD`, `mean ± SE`

Do not add, remove, or convert units without an explicit request. If spacing around units is inconsistent, flag or normalize only when the target journal style is known.

## Statistics

- Do not add "显著" without a statistical basis in the provided text.
- Do not change `P` to `p`, or `SD` to `SE`, unless the user requests style normalization and the meaning is verified.
- Preserve significance letters, asterisks, and figure/table annotations.
- Keep sample size and replicate descriptions unchanged.

## Citations and Cross References

Preserve citation content and placement:

- Numeric citations: `[1]`, `[2,3]`, `[4-6]`
- Author-year citations: `(Smith et al., 2020)`, `张等，2023`
- Figure/table references: `图1`, `表2`, `Fig. 3`, `Table S1`

Do not attach a citation to a different claim during rewriting.

## Latin Names and Gene/Protein Formatting

- Preserve Latin names, cultivar names, gene/protein symbols, transcript IDs, and accession numbers exactly.
- If the original text uses italics markers such as `*Arabidopsis thaliana*` or `<i>MdMYB10</i>`, keep them.
- If formatting is absent, do not add italics unless the user asks for a formatting pass.
- Keep spaces around Latin names and gene symbols readable in Chinese prose, but do not alter protected tokens.

## Chinese Scientific Style

Prefer:

- "本研究结果显示..."
- "在本实验条件下..."
- "该结果提示..."
- "仍需进一步验证..."
- "与...相比..."

Avoid unsupported:

- "充分证明..."
- "首次揭示..."
- "系统阐明..."
- "显著推动..."
- "具有重大战略意义..."

Use cautious terms only when they reflect real uncertainty, not as decorative hedging.
