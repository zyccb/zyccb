# 分章节处理策略

Use different cleaning intensity by manuscript section. If the section is unknown, use the safest middle ground: preserve structure and avoid strengthening claims.

## Abstract

Goal: concise, evidence-bounded summary.

Allowed:

- Remove empty background and broad significance phrases.
- Clarify research object, method, key results, and bounded conclusion.
- Keep quantitative results, treatment names, materials, species, and statistical terms unchanged.

Avoid:

- Adding mechanisms not stated in the text.
- Turning "candidate" into "key gene".
- Ending with broad "理论基础/实践价值" unless specific.

## Introduction

Goal: reduce template-heavy background while preserving scholarly logic.

Allowed:

- Compress repetitive importance statements.
- Replace broad claims with specific knowledge gaps.
- Keep citations attached to the claims they support.

Avoid:

- Removing necessary field context.
- Introducing new literature or claims without user-provided sources.
- Exaggerating novelty.

## Materials and Methods

Goal: maximum fidelity.

Allowed:

- Fix obvious Chinese fluency issues.
- Standardize repeated wording only when it does not alter protocol.

Avoid:

- Changing reagent names, concentrations, temperatures, durations, equipment, software, database versions, thresholds, sample sizes, or statistical methods.
- Inferring missing controls or parameters.
- Reordering procedure steps if it may change meaning.

## Results

Goal: clear, restrained presentation of observations.

Allowed:

- Remove repeated "结果表明" when the sentence can state the result directly.
- Keep figure/table references close to the corresponding claim.
- Narrow "显著" and "明显" to what the data support.

Avoid:

- Mechanistic interpretation unless the result directly tests it.
- Concluding "调控", "导致", "证明", or "关键因子" from expression, correlation, or enrichment alone.

## Discussion

Goal: improve reasoning while marking uncertainty.

Allowed:

- Clarify how current results compare with cited studies.
- Separate observed results, literature support, hypothesis, and limitations.
- Use cautious language for speculation.

Avoid:

- Making the discussion sound like a grant proposal.
- Adding unsupported "分子机制", "调控网络", or "理论基础".
- Stating causality when only association is shown.

## Conclusion

Goal: brief, scoped, and defensible.

Allowed:

- State the concrete finding and immediate implication.
- Keep "可能", "提示", or "可为...提供参考" where evidence is incomplete.

Avoid:

- Overbroad transfer to all species, cultivars, environments, or production systems.
- Claiming practical application from lab-only or single-season results unless supported.

## Figure Legends, Tables, and Captions

Goal: preserve exact mapping between labels and data.

Allowed:

- Light grammar cleanup.

Avoid:

- Changing abbreviations, group labels, significance letters, p-value notation, sample size, or statistical explanation.
