# 分子生物学术语与证据边界

Use this file for gene function, protein function, expression analysis, mutants, transgenic lines, regulatory networks, protein interaction, promoter analysis, and omics interpretation.

## Protected Terms

Preserve exact spelling, capitalization, punctuation, hyphens, italics markers, and numbering for:

- Gene symbols: `MdMYB10`, `AtABI5`, `VvWRKY`, `SlNAC`, `PpERF`, `LOC_Os01g01010`
- Protein names: `MdMYB10 protein`, `MdNAC1`, `ERF transcription factor`
- Mutants and lines: `myb10`, `abi5-1`, `OE-1`, `RNAi-3`, `CRISPR-2`, `35S::MdMYB10`
- Promoters and constructs: `ProMdMYB10`, `pMdMYB10::GUS`, `35S::`, `pCAMBIA1300`, `pBI121`, `pGreenII 0800-LUC`
- Alleles and transcript IDs: `AT1G01010`, `MD00G1234500`, `XM_`, `NM_`, `transcript_1`
- Primers and probes: `MdMYB10-F`, `MdMYB10-R`, `qMdACTIN-F`

Do not rewrite these as synonyms. Do not remove italics markers when they are already present. Many biological systems use italic gene symbols and roman protein symbols; preserve existing formatting unless the user asks for journal-specific formatting.

## Expression vs Regulation

Distinguish the measurement level:

- qRT-PCR, RT-qPCR, RNA-seq, Northern blot: transcript or expression level.
- Western blot, ELISA, targeted proteomics: protein abundance or protein accumulation.
- Enzyme activity assay: enzyme activity, not necessarily protein abundance.
- Metabolomics: metabolite abundance or content, not necessarily pathway activation.

Safer wording:

- "MdMYB10 表达量升高" for transcript-level evidence.
- "MdMYB10 蛋白积累增加" only when protein-level data exist.
- "基因上调" can be used for transcript-level comparison, but avoid using it for protein or metabolite results.

## Functional Claims

Expression changes alone do not establish gene function. For genes identified by RNA-seq, WGCNA, GWAS, QTL, or correlation, use:

- "候选基因"
- "可能参与"
- "与...相关"
- "有待进一步功能验证"

Functional language such as "参与", "影响", or "在...中发挥作用" is stronger and usually requires perturbation evidence such as mutant, overexpression, RNAi, VIGS, CRISPR/Cas, complementation, transient expression with phenotype, or rescue assays.

## Direct Regulation

Do not write "直接调控" unless direct target evidence is shown.

Evidence mapping:

- Promoter reporter assay, dual-luciferase: supports effect on promoter activity in that system.
- EMSA, Y1H, ChIP-qPCR, DAP-seq, CUT&Tag: supports binding evidence.
- Binding evidence plus expression or reporter evidence: may support direct regulation.
- Mutant expression changes alone: supports influence on expression, not direct binding.

Safer alternatives:

- "可能影响...表达"
- "可调节...启动子活性"
- "结合...启动子区域并影响其转录活性"
- "可能直接调控...，但仍需进一步验证" when evidence is partial.

## Protein Interaction

Use "互作" only with interaction evidence such as Y2H, BiFC, Co-IP, pull-down, split-luc, FRET, or related assays.

Editing rules:

- Co-expression, co-localization, pathway co-enrichment, or shared phenotype does not equal interaction.
- A single interaction assay may be reported cautiously: "提示可能互作", "支持二者存在互作".
- If downstream function of an interaction is not shown, do not add "形成复合体调控..." or "协同调控...".

## Omics and Enrichment

Do not overstate omics outputs:

- Differential expression: genes are differentially expressed, not automatically functional drivers.
- KEGG/GO enrichment: pathways or terms are enriched, not necessarily activated.
- WGCNA module: module is associated with trait, not necessarily causal.
- GWAS/QTL: locus or SNP is associated with trait, not proof of causal gene unless validated.

Safer wording:

- "富集于..."
- "与...相关的模块"
- "候选位点/候选基因"
- "提示该过程可能参与..."

## Formatting Sensitivity

When editing plain text, preserve existing markup such as `*MdMYB10*`, `<i>MdMYB10</i>`, subscripts, superscripts, Greek letters, and special symbols. If formatting is inconsistent, flag it instead of silently normalizing unless the user asks.
