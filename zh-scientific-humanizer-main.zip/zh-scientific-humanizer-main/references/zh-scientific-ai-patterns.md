# 中文科研 AI 味模式库

Use this file when cleaning Chinese scientific manuscript prose. The target is not casualization; the target is professional, restrained, evidence-bounded scientific writing.

## Empty Significance Inflation

Common risky patterns:

- "为...提供理论基础"
- "为...提供新思路"
- "为...奠定基础"
- "具有重要理论意义和实践价值"
- "对...具有重要指导意义"
- "推动...发展"
- "丰富了...理论体系"

Editing rules:

- Delete the phrase if it is only decorative.
- Narrow it to the actual use if the text provides a clear use case.
- Prefer "可为...提供参考" only when the reference target is specific and immediate.
- Avoid adding "理论基础" unless the work establishes a generalizable model or mechanism with strong evidence.

Safer examples:

- Risky: "本研究为苹果果实品质改良提供了理论基础。"
- Safer: "本研究鉴定了与苹果可溶性固形物和可滴定酸相关的候选基因，可为后续功能验证提供参考。"

## Mechanical Logical Connectors

Common overused connectors:

- "此外", "同时", "进一步", "值得注意的是", "综上所述", "由此可见", "因此", "然而", "与此同时", "不仅如此"

Editing rules:

- Keep a connector only if it states a real relationship: addition, contrast, cause, evidence hierarchy, or limitation.
- Delete repeated connectors when sentence order already expresses the relationship.
- Replace vague connectors with concrete logic when evidence supports it, such as "与该结果一致", "在相同处理下", "相较于叶片", "在成熟后期".

## Over-Strong Causality and Mechanism

Common risky patterns:

- "揭示了...机制"
- "证明...调控..."
- "导致...显著变化"
- "决定..."
- "阐明了...分子机制"
- "证实该基因是...关键因子"

Editing rules:

- If evidence is expression or correlation only, use "提示", "可能参与", "与...相关", "可能影响".
- If there is phenotype evidence but no direct target evidence, use "影响" or "参与", not "直接调控".
- Use "机制" only when the text contains sufficient mechanistic experiments and the section context supports a mechanistic conclusion.

## Results Generalization

Common risky patterns:

- "显著提高果实品质"
- "增强抗逆性"
- "促进生长发育"
- "改善产量和品质"
- "调控代谢过程"

Editing rules:

- Replace broad traits with measured indicators when available.
- Keep the scope: species, cultivar, tissue, developmental stage, treatment, and time point.
- Do not summarize several unrelated indicators as one improvement if they move in different directions.

Safer examples:

- Risky: "处理显著提高了果实品质。"
- Safer: "处理后可溶性固形物含量升高，可滴定酸含量降低，糖酸比增加。"

## Homogeneous Sentence Frames

Common patterns:

- "通过...发现..."
- "结果表明..."
- "进一步说明..."
- "这说明..."
- "研究发现..."
- "本研究首先...其次...最后..."

Editing rules:

- Do not remove all academic formulae; they are useful in moderation.
- Reduce repeated frames within the same paragraph.
- Start sentences with the measured object, condition, or result when that improves precision.
- Avoid adding decorative variation that changes scientific emphasis.

## Discussion Template Smell

Common patterns:

- Literature summary followed by "这与本研究结果一致" without explaining the shared condition.
- "可能是由于..." followed by unsupported mechanism.
- "未来仍需进一步研究" repeated without specifying the missing evidence.

Editing rules:

- State the comparison basis: species, tissue, treatment, developmental stage, or method.
- Mark speculation explicitly with "可能", "推测", or "有待进一步验证".
- Specify missing validation when known: genetic evidence, direct binding evidence, protein-level evidence, metabolite flux evidence, or independent population validation.
