# zh-scientific-humanizer

中文科研论文“去 AI 味”基础清理、学术润色与证据强度审校技能。

[English version](README.en.md)

## 简介

`zh-scientific-humanizer` 是一个 Codex skill，用于处理中文科研论文写作中的模板感、空泛意义拔高、过强因果、机械连接和句式同质化问题。它不是把论文改得口语化或“更有灵魂”，而是把文本清理成更像经过专业作者审校的科研文本。

该技能尤其关注植物学、园艺学、果树学、植物分子生物学、遗传学和组学分析等场景，默认保护术语、数据、处理编号、物种名、品种名、基因/蛋白名、统计结果、引用关系和图表编号。

## 主要能力

- **基础清理版**：默认模式，只清理模板词、冗余连接、空泛表达和重复句式，不改变论证结构。
- **学术润色版**：优化句式和逻辑衔接，同时保留原始术语、数据和证据边界。
- **风险标注版**：指出“机制过强”“显著性无依据”“术语可能不准”“结论拔高”等问题。

## 适用场景

- 中文论文摘要、引言、结果、讨论和结论的去模板化清理。
- 植物学、园艺学、果树学论文中物种名、品种名、种质、砧木、接穗和果实品质指标的保护。
- 分子生物学文本中基因名、蛋白名、突变体、启动子、载体、引物、转录本编号和互作/调控证据边界的保护。
- 检查是否把相关性写成因果、表达差异写成功能验证、趋势写成显著差异、候选基因写成机制结论。

## 安装

将仓库克隆到 Codex skills 目录：

```powershell
git clone https://github.com/XuanjinZhu/zh-scientific-humanizer.git "$env:USERPROFILE\.codex\skills\zh-scientific-humanizer"
```

然后重启 Codex，使新技能被加载。

如果本地已经存在同名技能目录，先备份或手动合并，不要直接覆盖未确认的修改。

## 使用示例

```text
使用 $zh-scientific-humanizer 帮我把下面这段中文论文讨论部分做基础清理，保留术语和证据边界。
```

```text
使用 $zh-scientific-humanizer 对这段果树学论文结论做风险标注，重点检查显著性、机制、调控和互作表述是否过强。
```

## 文件结构

```text
.
├── SKILL.md
├── agents/
│   └── openai.yaml
└── references/
    ├── claim-strength-checklist.md
    ├── molecular-biology-guardrails.md
    ├── plant-horticulture-terms.md
    ├── punctuation-formatting.md
    ├── section-specific-rewrite.md
    └── zh-scientific-ai-patterns.md
```

## 设计原则

- 不承诺或优化任何 AIGC 检测分数。
- 不加入主观情绪、第一人称、幽默、口语化表达或原文没有的新信息。
- 不改变数据、处理名称、物种名、品种名、基因名、蛋白名、统计结果和引用关系。
- 优先删除空泛意义、模板化连接、过强结论和重复表达。
- 保留必要的学术谨慎和专业术语密度。

## 参考依据

- International Code of Nomenclature for algae, fungi, and plants: https://www.iaptglobal.org/icn/
- Madrid Code Online: https://www.iaptglobal.org/_functions/code/madrid
- International Code of Nomenclature for Cultivated Plants, Ninth Edition: https://ishs.org/scripta-horticulturae/international-code-nomenclature-cultivated-plants-ninth-edition/
- FAO cultivar naming overview: https://www.fao.org/ipc/areas-of-work/wp-gen-working-party-on-genetic-resources/how-to-name-a-new-cultivar/fr/

## 许可协议

本项目使用 MIT-0 协议发布，见 [LICENSE](LICENSE)。
