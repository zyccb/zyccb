# zh-scientific-humanizer

A Codex skill for cleaning AI-like template language in Chinese scientific manuscripts while preserving academic rigor, terminology, data, and evidence boundaries.

[中文说明](README.md)

## Overview

`zh-scientific-humanizer` is designed for Chinese scientific writing, especially botany, horticulture, pomology/fruit science, plant molecular biology, genetics, and omics manuscripts. It does not make scientific prose casual, personal, humorous, or "more soulful." Instead, it removes template-like phrasing, empty significance inflation, over-strong causality, mechanical transitions, and repetitive sentence patterns.

The skill protects species names, cultivar names, germplasm/material labels, treatment IDs, gene/protein symbols, statistical results, citations, and figure/table references.

## Modes

- **Basic cleanup**: default mode; removes template phrases, redundant transitions, empty claims, and repeated wording without changing the argument structure.
- **Academic polishing**: improves sentence flow and local logic while preserving terminology, data, and evidence strength.
- **Risk annotation**: flags issues such as over-strong mechanisms, unsupported significance, imprecise terminology, and over-generalized conclusions.

## Use Cases

- Cleaning Chinese manuscript abstracts, introductions, results, discussions, and conclusions.
- Protecting botanical and horticultural names, cultivars, germplasm, rootstock, scion, and fruit-quality indicators.
- Preserving molecular biology terms such as gene names, protein names, mutants, promoters, vectors, primers, transcript IDs, and interaction/regulation evidence boundaries.
- Auditing whether correlation has been overstated as causation, expression difference as functional validation, trend as significance, or candidate genes as mechanism-level conclusions.

## Installation

Clone the repository into your Codex skills directory:

```powershell
git clone https://github.com/XuanjinZhu/zh-scientific-humanizer.git "$env:USERPROFILE\.codex\skills\zh-scientific-humanizer"
```

Restart Codex after installation.

If a skill directory with the same name already exists, back it up or merge manually instead of overwriting unreviewed changes.

## Example Prompts

```text
Use $zh-scientific-humanizer to clean the following Chinese manuscript discussion section while preserving terminology and evidence boundaries.
```

```text
Use $zh-scientific-humanizer to annotate risks in this pomology conclusion, focusing on significance, mechanism, regulation, and interaction claims.
```

## Structure

```text
.
├── SKILL.md
├── agents/
│   └── openai.yaml
└── references/
    ├── claim-strength-checklist.md
    ├── molecular-biology-guardrails.md
    ├── plant-horticulture-terms.md
    ├── punctuation-formatting.md
    ├── section-specific-rewrite.md
    └── zh-scientific-ai-patterns.md
```

## Principles

- Do not promise or optimize for any AIGC detector score.
- Do not add subjective emotion, first-person voice, humor, casual language, or unsupported new information.
- Do not alter data, treatment names, species names, cultivar names, gene names, protein names, statistical results, or citation relationships.
- Prefer deleting empty significance, template connectors, over-strong conclusions, and repeated phrasing.
- Preserve necessary academic caution and domain-specific terminology density.

## References

- International Code of Nomenclature for algae, fungi, and plants: https://www.iaptglobal.org/icn/
- Madrid Code Online: https://www.iaptglobal.org/_functions/code/madrid
- International Code of Nomenclature for Cultivated Plants, Ninth Edition: https://ishs.org/scripta-horticulturae/international-code-nomenclature-cultivated-plants-ninth-edition/
- FAO cultivar naming overview: https://www.fao.org/ipc/areas-of-work/wp-gen-working-party-on-genetic-resources/how-to-name-a-new-cultivar/fr/

## License

Released under the MIT-0 license. See [LICENSE](LICENSE).
